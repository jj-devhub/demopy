# demopy

A demo PyPI package for CI/CD publishing.
